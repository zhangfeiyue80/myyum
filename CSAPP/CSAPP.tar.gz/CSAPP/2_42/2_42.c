#include <stdio.h>
#include "../basic.h"
int div16(int x)
{
	unsigned int factor;
	factor=posi_neg(x);
	return x+((1<<k)-1);
}

int main()
{
//	printf("unsigned int所占字节数为%d\n",sizeof(unsigned int));
}
