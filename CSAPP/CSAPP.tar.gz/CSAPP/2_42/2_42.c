#include <stdio.h>
int div16(int x)
{
	
}
