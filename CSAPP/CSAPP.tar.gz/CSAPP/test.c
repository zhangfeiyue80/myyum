#include "basic.h"
int main()
{
	long int x;
	define_sizeof("long int",x);
	return 0;
}
