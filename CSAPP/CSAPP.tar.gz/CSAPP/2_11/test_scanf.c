#include<stdio.h>
#include<stdlib.h>
int main()
{
	int number=0;
	scanf("%d",&number);
	printf("输入的值为%d\n",number);
	return 0;
}
